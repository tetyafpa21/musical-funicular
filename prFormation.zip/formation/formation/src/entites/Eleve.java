package entites;

public class Eleve {
	int id;
	String nom;
	String prenom;
	String ville;
	Integer id_programme;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public Integer getId_programme() {
		return id_programme;
	}

	public void setId_programme(int id_programme) {
		this.id_programme = id_programme;
	}

	@Override
	public String toString() {
		return "ELEVE> [Num�ro: " + id + ", Nom: " + nom + ", Prenom: " + prenom + ", Ville: " + ville + ", Programme: "
				+ id_programme + "]";
	}

	public Eleve(String nom, String prenom, String ville, int id_programme) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.ville = ville;
		this.id_programme = id_programme;
	}

	public Eleve(String nom, String prenom, String ville) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.ville = ville;
	}

	public Eleve() {
		super();
	}
}
