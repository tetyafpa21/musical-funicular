package entites;

public class Centre {
	int id;
	String nom;
	String adresse;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	@Override
	public String toString() {
		return "CENTRE> [Num�ro: " + id + ", Nom: " + nom + ", Adresse: " + adresse + "]";
	}

	public Centre(int id, String nom, String adresse) {
		super();
		this.id = id;
		this.nom = nom;
		this.adresse = adresse;
	}

	public Centre(String nom, String adresse) {
		super();
		this.nom = nom;
		this.adresse = adresse;
	}

	public Centre() {
		super();
	}

}
