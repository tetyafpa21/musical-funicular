package entites;

public class Professeur {
	int id;
	String nom;
	String prenom;
	int id_matiere;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public int getId_matiere() {
		return id_matiere;
	}

	public void setId_matiere(int id_matiere) {
		this.id_matiere = id_matiere;
	}

	@Override
	public String toString() {
		return "PROFESSEUR> [Num�ro: " + id + ", Nom: " + nom + ", Pr�nom: " + prenom + ", Matiere: " + id_matiere
				+ "]";
	}

	public Professeur(int id, String nom, String prenom, int id_matiere) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.id_matiere = id_matiere;
	}

	public Professeur(String nom, String prenom, int id_matiere) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.id_matiere = id_matiere;
	}

	public Professeur() {
		super();
	}

}
