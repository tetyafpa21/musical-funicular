package entites;

public class ProgrammeMatiere {

	int id;
	int id_programme;
	int id_matiere;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_programme() {
		return id_programme;
	}

	public void setId_programme(int id_programme) {
		this.id_programme = id_programme;
	}

	public int getId_matiere() {
		return id_matiere;
	}

	public void setId_matiere(int id_matiere) {
		this.id_matiere = id_matiere;
	}

	@Override
	public String toString() {
		return "PROGRAMME et MATIERE> [Num�ro" + id + ", Programe: " + id_programme + ", Matiere: " + id_matiere + "]";
	}

	public ProgrammeMatiere(int id_programme, int id_matiere) {
		super();
		this.id_programme = id_programme;
		this.id_matiere = id_matiere;
	}

	public ProgrammeMatiere() {
		super();
	}

}
