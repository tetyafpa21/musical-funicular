package entites;

public class Note {
int id;
float note;
int id_matiere;
int id_eleve;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public float getNote() {
	return note;
}
public void setNote(float note) {
	this.note = note;
}
public int getId_matiere() {
	return id_matiere;
}
public void setId_matiere(int id_matiere) {
	this.id_matiere = id_matiere;
}
public int getId_eleve() {
	return id_eleve;
}
public void setId_eleve(int id_eleve) {
	this.id_eleve = id_eleve;
}
@Override
public String toString() {
	return "NOTE> [Num�ro: " + id + ", Note: " + note + ", Matiere: " + id_matiere + ", Eleve: " + id_eleve + "]";
}
public Note(float note, int id_matiere, int id_eleve) {
	super();
	this.note = note;
	this.id_matiere = id_matiere;
	this.id_eleve = id_eleve;
}
public Note() {
	super();
}


}
