package entites;

import java.util.Date;

public class Programme {
	int id;
	Date date_debut;

	public Date getDate_debut() {
		return date_debut;
	}

	public Date getDate_fin() {
		return date_fin;
	}

	Date date_fin;
	String nom;
	int id_formation;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setDate_debut(Date date_debut) {
		this.date_debut = date_debut;
	}

	public void setDate_fin(Date date_fin) {
		this.date_fin = date_fin;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getId_formation() {
		return id_formation;
	}

	public void setId_formation(int id_formation) {
		this.id_formation = id_formation;
	}

	@Override
	public String toString() {
		return "PROGRAMME> [Num�ro: " + id + ", D�but: " + date_debut + ", Fin: " + date_fin + ", Nom: " + nom
				+ ", Formation: " + id_formation + "]";
	}

	public Programme(Date date_debut, Date date_fin, String nom, int id_formation) {
		super();
		this.date_debut = date_debut;
		this.date_fin = date_fin;
		this.nom = nom;
		this.id_formation = id_formation;
	}

	public Programme(Date date_debut, Date date_fin) {
		super();
		this.date_debut = date_debut;
		this.date_fin = date_fin;

	}

	public Programme() {
		super();
	}

}
