package entites;

public class Matiere {
	int id;
	String nom;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	@Override
	public String toString() {
		return "MATIERE> [Num�ro: " + id + ", Nom: " + nom + "]";
	}

	public Matiere(int id, String nom) {
		super();
		this.id = id;
		this.nom = nom;
	}

	public Matiere(String nom) {
		super();
		this.nom = nom;
	}

	public Matiere() {
		super();
	}

}
