package entites;

public class Formation {
	int id;
	String nom;
	int id_centre;
	float prix;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getId_centre() {
		return id_centre;
	}

	public void setId_centre(int id_centre) {
		this.id_centre = id_centre;
	}

	public float getPrix() {
		return prix;
	}

	public void setPrix(float prix) {
		this.prix = prix;
	}

	@Override
	public String toString() {
		return "FORMATION> [Num�ro: " + id + ", Nom: " + nom + ", Centre: " + id_centre + ", Prix: " + prix + "]";
	}

	public Formation(int id, String nom, int id_centre, float prix) {
		super();
		this.id = id;
		this.nom = nom;
		this.id_centre = id;
		this.prix = prix;
	}

	public Formation(String nom, float prix) {
		super();
		this.nom = nom;
		this.prix = prix;
	}

	public Formation(String nom, int id_centre, float prix) {
		super();
		this.nom = nom;
		this.id_centre = id_centre;
		this.prix = prix;
	}

	public Formation() {

	}

}
