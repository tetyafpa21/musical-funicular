package entites;

import java.util.Date;

public class Diplome {

	int id;
	String nom;
	Date date;
	String niveau;
	int id_eleve;

	public int getId_eleve() {
		return id_eleve;
	}

	public void setId_eleve(int id_eleve) {
		this.id_eleve = id_eleve;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getNiveau() {
		return niveau;
	}

	public void setNiveau(String niveau) {
		this.niveau = niveau;
	}

	@Override
	public String toString() {
		return "DIPLOME> [Num�ro" + id + ", Titre: " + nom + ", Date:" + date + ", Niveau: " + niveau + ", Eleve: " + id_eleve + "]";
	}

	public Diplome(String nom, Date date, String niveau, int id_eleve) {
		super();
		this.nom = nom;
		this.date = date;
		this.niveau = niveau;
		this.id_eleve = id_eleve;
	}

	public Diplome() {
		super();
	}

}
