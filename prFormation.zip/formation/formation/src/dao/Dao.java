package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dao {

	protected String dburl = "jdbc:mysql://localhost:3306/formation";
	protected String dbuser = "fred";
	protected String dbpass = "fred";

	public Dao() {
		super();
	}

	protected Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			return DriverManager.getConnection(dburl, dbuser, dbpass);
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}

}