package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import entites.Note;

public class NoteDao extends Dao {

	public NoteDao() {

	}

	public void save(Note note) {

		try {

			Connection connexion = this.getConnection();
//updape (on donne id objet)
			if (note.getId() != 0) {
				PreparedStatement ps = connexion
						.prepareStatement("UPDATE note set note=?, id_matiere=? id_eleve=? WHERE id=?");
				ps.setFloat(1, note.getNote());
				ps.setInt(2, note.getId_matiere());
				ps.setInt(3, note.getId_eleve());
				ps.setInt(4, note.getId());
				ps.executeUpdate();
//creation cars sans id
			} else {
				PreparedStatement ps = connexion
						.prepareStatement("INSERT INTO note (note, id_matiere, id_eleve) VALUES(?,?,?)");
				ps.setFloat(1, note.getNote());
				ps.setInt(2, note.getId_matiere());
				ps.setInt(3, note.getId_eleve());
				ps.executeUpdate();
			}
			System.out.println("SAVED OK");
			connexion.close();

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}
	}

	public Note getById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM note WHERE id=?");
			ps.setInt(1, id);

			ResultSet resultat = ps.executeQuery();

			Note c = new Note();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNote(resultat.getFloat("note"));
				c.setId_matiere(resultat.getInt("id_matiere"));
				c.setId_eleve(resultat.getInt("id_eleve"));
			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Note> getByEleve(int id_eleve) {
		ArrayList<Note> note = new ArrayList<Note>();
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM note WHERE id_eleve = ?");
			ps.setInt(1, id_eleve);

			ResultSet resultat = ps.executeQuery();

			while (resultat.next()) {
				Note c = new Note();
				c.setId(resultat.getInt("id"));
				c.setNote(resultat.getFloat("note"));

				c.setId_matiere(resultat.getInt("id_matiere"));
				c.setId_eleve(resultat.getInt("id_eleve"));

				note.add(c);
			}
			return note;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}
	}

	public ArrayList<Note> getAll() {
		ArrayList<Note> note = new ArrayList<Note>();
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM note");

			ResultSet resultat = ps.executeQuery();

			while (resultat.next()) {
				Note c = new Note();
				c.setId(resultat.getInt("id"));
				c.setNote(resultat.getFloat("note"));

				c.setId_matiere(resultat.getInt("id_matiere"));
				c.setId_eleve(resultat.getInt("id_eleve"));

				note.add(c);
			}
			return note;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}
	}

	public void deleteById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("DELETE FROM note WHERE id=?");
			ps.setInt(1, id);

			ps.executeUpdate();

			System.out.println("DELETED by Id, OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED by Id, NO");
		}
	}
}