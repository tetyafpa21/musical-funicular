package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import entites.Programme;

public class ProgrammeDao extends Dao {

	public ProgrammeDao() {

	}

	public void save(Programme programme) {

		try {

			Connection connexion = this.getConnection();
			// updape (on donne id objet)
			if (programme.getId() != 0) {
				PreparedStatement ps = connexion.prepareStatement(
						"UPDATE programme set date_debut=?,date_fin=?,nom=?,id_formation=? WHERE id=?");
				ps.setDate(1, new java.sql.Date(programme.getDate_debut().getTime()));
				ps.setDate(2, new java.sql.Date(programme.getDate_fin().getTime()));
				ps.setString(3, programme.getNom());
				ps.setInt(4, programme.getId_formation());
				ps.setInt(5, programme.getId());
				ps.executeUpdate();
				// creation cars sans id
			} else {
				PreparedStatement ps = connexion.prepareStatement(
						"INSERT INTO programme (date_debut,date_fin,nom,id_formation) VALUES(?,?,?,?)");
				ps.setDate(1, new java.sql.Date(programme.getDate_debut().getTime()));
				ps.setDate(2, new java.sql.Date(programme.getDate_fin().getTime()));
				ps.setString(3, programme.getNom());
				ps.setInt(4, programme.getId_formation());
				ps.executeUpdate();
			}
			System.out.println("SAVED OK");
			connexion.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public Programme getById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM programme WHERE id=?");
			ps.setInt(1, id);

			ResultSet resultat = ps.executeQuery();

			Programme c = new Programme();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setDate_debut(resultat.getDate("date_debut"));
				c.setDate_fin(resultat.getDate("date_fin"));
				c.setNom(resultat.getString("nom"));
				c.setId_formation(resultat.getInt("id_formation"));

			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public Programme getByName(String nom) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM programme WHERE UPPER(nom) like ?");
			ps.setString(1, "%" + nom.toUpperCase() + "%");

			ResultSet resultat = ps.executeQuery();

			Programme c = new Programme();
			if (resultat.next()) {
				c.setDate_debut(resultat.getDate("date_debut"));
				c.setDate_fin(resultat.getDate("date_fin"));
				c.setNom(resultat.getString("nom"));
				c.setId_formation(resultat.getInt("id_formation"));
				c.setId(resultat.getInt("id"));

			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Programme> getAll() {
		ArrayList<Programme> programme = new ArrayList<Programme>();
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM programme");

			ResultSet resultat = ps.executeQuery();

			while (resultat.next()) {
				Programme c = new Programme();

				c.setId(resultat.getInt("id"));
				c.setDate_debut(resultat.getDate("date_debut"));
				c.setDate_fin(resultat.getDate("date_fin"));
				c.setNom(resultat.getString("nom"));
				c.setId_formation(resultat.getInt("id_formation"));

				programme.add(c);
			}
			return programme;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}
	}
	
	public ArrayList<Programme> getAllByFormation(int id_formation) {
		ArrayList<Programme> programme = new ArrayList<Programme>();
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM programme WHERE id_formation = ?");
			ps.setInt(1, id_formation);

			ResultSet resultat = ps.executeQuery();

			while (resultat.next()) {
				Programme c = new Programme();

				c.setId(resultat.getInt("id"));
				c.setDate_debut(resultat.getDate("date_debut"));
				c.setDate_fin(resultat.getDate("date_fin"));
				c.setNom(resultat.getString("nom"));
				c.setId_formation(resultat.getInt("id_formation"));

				programme.add(c);
			}
			return programme;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}
	}

	public void deleteById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("DELETE FROM programme WHERE id=?");
			ps.setInt(1, id);

			ps.executeUpdate();

			System.out.println("DELETED by Id, OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED by Id, NO");
		}
	}
}