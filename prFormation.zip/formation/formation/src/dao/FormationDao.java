	package dao;

	import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import entites.Formation;

	public class FormationDao extends Dao {

		
		    public FormationDao() {

		    }

		    public void save(Formation formation) {

		        try {
		            
		            Connection connexion = this.getConnection();
	//updape (on donne id objet)
		            if (formation.getId() != 0) {
		                PreparedStatement ps = connexion
		                        .prepareStatement("UPDATE formation set nom=?,id_centre=?,prix=? WHERE id=?");
		                ps.setString(1, formation.getNom());
		                ps.setInt(2, formation.getId_centre());
		                ps.setFloat(3, formation.getPrix());
		                ps.setInt(4, formation.getId());
		                ps.executeUpdate();
	//creation cars sans id
		            } else {
		                PreparedStatement ps = connexion
		                        .prepareStatement("INSERT INTO formation (nom,id_centre,prix) VALUES(?,?,?)");
		                ps.setString(1, formation.getNom());
		                ps.setInt(2, formation.getId_centre());
		                ps.setFloat(3, formation.getPrix());
		         	    ps.executeUpdate();
		            }
		            System.out.println("SAVED OK");
		            connexion.close();
		        } catch (Exception ex) {
		            ex.printStackTrace();
		            System.out.println("SAVED NO");
		        }

		    }

		    public Formation getById(int id) {
		        try {
		        	Connection connexion = this.getConnection();

		            PreparedStatement ps = connexion.prepareStatement("SELECT * FROM formation WHERE id=?");
		            ps.setInt(1, id);

		            ResultSet resultat = ps.executeQuery();

		            Formation c = new Formation();
		            if (resultat.next()) {
		                c.setId(resultat.getInt("id"));
		                c.setNom(resultat.getString("nom"));
		                c.setId_centre(resultat.getInt("id_centre"));
		                c.setPrix(resultat.getFloat("prix"));
		                
		            }
		            return c;
		            	        } catch (Exception ex) {
		            ex.printStackTrace();
		            return null;
		           	        }
		    }
		    
		    public Formation getByName(String nom) {
		        try {
		        	Connection connexion = this.getConnection();

		            PreparedStatement ps = connexion.prepareStatement("SELECT * FROM formation WHERE UPPER(nom) like ?");
		            ps.setString(1, "%" + nom.toUpperCase() + "%");

		            ResultSet resultat = ps.executeQuery();

		            Formation c = new Formation();
		            if (resultat.next()) {
		                c.setId(resultat.getInt("id"));
		                c.setNom(resultat.getString("nom"));
		                c.setId_centre(resultat.getInt("id_centre"));
		                c.setPrix(resultat.getFloat("prix"));
		                
		            }
		            return c;
		            	        } catch (Exception ex) {
		            ex.printStackTrace();
		            return null;
		           	        }
		    }

		    public ArrayList<Formation> getAll() {
		        ArrayList<Formation> formation = new ArrayList<Formation>();
		        try {
		        	Connection connexion = this.getConnection();

		            PreparedStatement ps = connexion.prepareStatement("SELECT * FROM formation");

		            ResultSet resultat = ps.executeQuery();

		            while (resultat.next()) {
		            	Formation c = new Formation();
		                c.setId(resultat.getInt("id"));
		                c.setNom(resultat.getString("nom"));
		                c.setId_centre(resultat.getInt("id_centre"));
		                c.setPrix(resultat.getFloat("prix"));
		               formation.add(c);
		            }
		            return formation;
		            
		        } catch (Exception ex) {
		            ex.printStackTrace();
		            return null;
		            
		        }
		    }

		    public void deleteById(int id) {
		        try {
		        	Connection connexion = this.getConnection();

		            PreparedStatement ps = connexion.prepareStatement("DELETE FROM formation WHERE id=?");
		            ps.setInt(1, id);

		            ps.executeUpdate();

		            System.out.println("DELETED by Id, OK");

		        } catch (Exception ex) {
		            ex.printStackTrace();
		            System.out.println("DELETED by Id, NO");
		        }
		    }
		}