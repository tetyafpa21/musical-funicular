package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import entites.ProgrammeMatiere;

public class ProgrameMatiereDao extends Dao {

	public ProgrameMatiereDao() {

	}

	public void save(ProgrammeMatiere programme_matiere) {

		try {

			Connection connexion = this.getConnection();
			// updape (on donne id objet)
			if (programme_matiere.getId() != 0) {
				PreparedStatement ps = connexion
						.prepareStatement("UPDATE programme_matiere set id_programme=?,id_matiere=?,  WHERE id=?");
				ps.setInt(1, programme_matiere.getId_programme());
				ps.setInt(2, programme_matiere.getId_matiere());
				ps.setInt(3, programme_matiere.getId());
				ps.executeUpdate();
				// creation cars sans id
			} else {
				PreparedStatement ps = connexion
						.prepareStatement("INSERT INTO programme_matiere (id_programme, id_matiere) VALUES(?,?)");
				ps.setInt(1, programme_matiere.getId_programme());
				ps.setInt(2, programme_matiere.getId_matiere());
				ps.executeUpdate();
			}
			System.out.println("SAVED OK");
			connexion.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public ProgrammeMatiere getById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM programme_matiere WHERE id=?");
			ps.setInt(1, id);

			ResultSet resultat = ps.executeQuery();

			ProgrammeMatiere c = new ProgrammeMatiere();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setId_programme(resultat.getInt("id_programme"));
				c.setId_matiere(resultat.getInt("id_matiere"));

			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ProgrammeMatiere getById_programme(int id_programme) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM programme_matiere WHERE id_programme=?");
			ps.setInt(1, id_programme);

			ResultSet resultat = ps.executeQuery();

			ProgrammeMatiere c = new ProgrammeMatiere();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setId_programme(resultat.getInt("id_programme"));
				c.setId_matiere(resultat.getInt("id_matiere"));

			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<ProgrammeMatiere> getAll() {
		ArrayList<ProgrammeMatiere> programme_matiere = new ArrayList<ProgrammeMatiere>();
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM programme_matiere");

			ResultSet resultat = ps.executeQuery();

			while (resultat.next()) {
				ProgrammeMatiere c = new ProgrammeMatiere();
				c.setId(resultat.getInt("id"));
				c.setId_programme(resultat.getInt("id_programme"));
				c.setId_matiere(resultat.getInt("id_matiere"));

				programme_matiere.add(c);
			}
			return programme_matiere;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}
	}

	public void deleteById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("DELETE FROM programme_matiere WHERE id=?");
			ps.setInt(1, id);

			ps.executeUpdate();

			System.out.println("DELETED by Id, OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED by Id, NO");
		}
	}
}