package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import entites.Professeur;

public class ProfesseurDao extends Dao {

	public ProfesseurDao() {

	}

	public void save(Professeur professeur) {

		try {

			Connection connexion = this.getConnection();
//updape (on donne id objet)
			if (professeur.getId() != 0) {
				PreparedStatement ps = connexion
						.prepareStatement("UPDATE professeur set nom=?, prenom=? id_matiere=? WHERE id=?");
				ps.setString(1, professeur.getNom());
				ps.setString(2, professeur.getPrenom());
				ps.setInt(3, professeur.getId_matiere());
				ps.setInt(4, professeur.getId());
				ps.executeUpdate();
//creation cars sans id
			} else {
				PreparedStatement ps = connexion
						.prepareStatement("INSERT INTO professeur (nom, prenom, id_matiere) VALUES(?,?,?)");
				ps.setString(1, professeur.getNom());
				ps.setString(2, professeur.getPrenom());
				ps.setInt(3, professeur.getId_matiere());
				ps.executeUpdate();
			}
			System.out.println("SAVED OK");
			connexion.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public Professeur getById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM professeur WHERE id=?");
			ps.setInt(1, id);

			ResultSet resultat = ps.executeQuery();

			Professeur c = new Professeur();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setPrenom(resultat.getString("prenom"));				;
				c.setId_matiere(resultat.getInt("id_matiere"));
			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public Professeur getByName(String nom) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM professeur WHERE UPPER(nom) like ?");
			ps.setString(1, "%" + nom.toUpperCase() + "%");

			ResultSet resultat = ps.executeQuery();

			Professeur c = new Professeur();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setPrenom(resultat.getString("prenom"));				
				c.setId_matiere(resultat.getInt("id_matiere"));
			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Professeur> getAll() {
		ArrayList<Professeur> professeur = new ArrayList<Professeur>();
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM professeur");

			ResultSet resultat = ps.executeQuery();

			while (resultat.next()) {
				Professeur c = new Professeur();
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setPrenom(resultat.getString("prenom"));				
				c.setId_matiere(resultat.getInt("id_matiere"));

				professeur.add(c);
			}
			return professeur;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}
	}

	public void deleteById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("DELETE FROM professeur WHERE id=?");
			ps.setInt(1, id);

			ps.executeUpdate();

			System.out.println("DELETED by Id, OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED by Id, NO");
		}
	}

	public Professeur getByMatiere(int id_matiere) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM professeur WHERE id_matiere=?");
			ps.setInt(1, id_matiere);

			ResultSet resultat = ps.executeQuery();

			Professeur c = new Professeur();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setPrenom(resultat.getString("prenom"));				;
				c.setId_matiere(resultat.getInt("id_matiere"));
			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
}