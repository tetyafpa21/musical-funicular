package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import entites.Matiere;

public class MatiereDao extends Dao {

	public MatiereDao() {

	}

	public void save(Matiere matiere) {

		try {

			Connection connexion = this.getConnection();
//updape (on donne id objet)
			if (matiere.getId() != 0) {
				PreparedStatement ps = connexion.prepareStatement("UPDATE matiere set nom=? WHERE id=?");
				ps.setString(1, matiere.getNom());
				ps.setInt(2, matiere.getId());
				ps.executeUpdate();
//creation cars sans id
			} else {
				PreparedStatement ps = connexion.prepareStatement("INSERT INTO matiere (nom) VALUES(?)");

				ps.setString(1, matiere.getNom());
				ps.executeUpdate();
			}
			System.out.println("SAVED OK");
			connexion.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public Matiere getById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM matiere WHERE id=?");
			ps.setInt(1, id);

			ResultSet resultat = ps.executeQuery();

			Matiere c = new Matiere();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));

			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public Matiere getByName(String nom) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM matiere WHERE UPPER(nom) like ?");
			ps.setString(1, "%" + nom.toUpperCase() + "%");

			ResultSet resultat = ps.executeQuery();

			Matiere c = new Matiere();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));

			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Matiere> getAll() {
		ArrayList<Matiere> matiere = new ArrayList<Matiere>();
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM matiere");

			ResultSet resultat = ps.executeQuery();

			while (resultat.next()) {
				Matiere c = new Matiere();

				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));

				matiere.add(c);
			}
			return matiere;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}
	}

	public void deleteById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("DELETE FROM matiere WHERE id=?");
			ps.setInt(1, id);

			ps.executeUpdate();

			System.out.println("DELETED by Id, OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED by Id, NO");
		}
	}
}