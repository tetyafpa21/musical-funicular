package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import entites.Centre;

public class CentreDao extends Dao {

	public CentreDao() {

	}

	public void save(Centre centre) {

		try {

			Connection connexion = this.getConnection();
//updape (on donne id objet)
			if (centre.getId() != 0) {
				PreparedStatement ps = connexion.prepareStatement("UPDATE centre set nom=?,adresse=? WHERE id=?");
				ps.setString(1, centre.getNom());
				ps.setString(2, centre.getAdresse());
				ps.setInt(3, centre.getId());
				ps.executeUpdate();
//creation cars sans id
			} else {
				PreparedStatement ps = connexion.prepareStatement("INSERT INTO centre (nom,adresse) VALUES(?,?)");
				ps.setString(1, centre.getNom());
				ps.setString(2, centre.getAdresse());
				ps.executeUpdate();
			}
			System.out.println("SAVED OK");
			connexion.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public Centre getById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM centre WHERE id=?");
			ps.setInt(1, id);

			ResultSet resultat = ps.executeQuery();

			Centre c = new Centre();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setAdresse(resultat.getString("adresse"));

			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public Centre getByName(String nom) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM centre WHERE UPPER(nom) like ?");
			ps.setString(1, "%" + nom.toUpperCase() + "%");

			ResultSet resultat = ps.executeQuery();

			Centre c = new Centre();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setAdresse(resultat.getString("adresse"));

			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Centre> getAll() {
		ArrayList<Centre> centre = new ArrayList<Centre>();
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM centre");

			ResultSet resultat = ps.executeQuery();

			while (resultat.next()) {
				Centre c = new Centre();
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setAdresse(resultat.getString("adresse"));
				centre.add(c);
			}
			return centre;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}
	}

	public void deleteById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("DELETE FROM centre WHERE id=?");
			ps.setInt(1, id);

			ps.executeUpdate();

			System.out.println("DELETED by Id, OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED by Id, NO");
		}
	}
}