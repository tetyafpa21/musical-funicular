package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import entites.Diplome;

public class DiplomeDao extends Dao {

	public DiplomeDao() {

	}

	public void save(Diplome diplome) {

		try {

			Connection connexion = this.getConnection();
			// updape (on donne id objet)
			if (diplome.getId() != 0) {
				PreparedStatement ps = connexion
						.prepareStatement("UPDATE diplome set nom=?,date=?,niveau=?,id_eleve=? WHERE id=?");
				ps.setString(1, diplome.getNom());
				ps.setDate(2, new java.sql.Date(diplome.getDate().getTime()));
				ps.setString(3, diplome.getNiveau());
				ps.setInt(4, diplome.getId());
				ps.setInt(5, diplome.getId_eleve());
				ps.executeUpdate();
				// creation cars sans id
			} else {
				PreparedStatement ps = connexion
						.prepareStatement("INSERT INTO diplome (nom,date,niveau,id_eleve) VALUES(?,?,?,?)");
				ps.setString(1, diplome.getNom());
				ps.setDate(2, new java.sql.Date(diplome.getDate().getTime()));
				ps.setString(3, diplome.getNiveau());
				ps.setInt(4, diplome.getId_eleve());
				ps.executeUpdate();
			}
			System.out.println("SAVED OK");
			connexion.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public Diplome getById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM diplome WHERE id=?");
			ps.setInt(1, id);

			ResultSet resultat = ps.executeQuery();

			Diplome c = new Diplome();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setDate(resultat.getDate("date"));
				c.setNiveau(resultat.getString("niveau"));
				c.setId_eleve(resultat.getInt("id_eleve"));
			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public Diplome getByName(String nom) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM diplome WHERE UPPER(nom) like ?");
			ps.setString(1, "%" + nom.toUpperCase() + "%");

			ResultSet resultat = ps.executeQuery();

			Diplome c = new Diplome();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setDate(resultat.getDate("date"));
				c.setNiveau(resultat.getString("niveau"));
				c.setId_eleve(resultat.getInt("id_eleve"));
			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Diplome> getAll() {
		ArrayList<Diplome> diplome = new ArrayList<Diplome>();
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM diplome");

			ResultSet resultat = ps.executeQuery();

			while (resultat.next()) {
				Diplome c = new Diplome();
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setDate(resultat.getDate("date"));
				c.setNiveau(resultat.getString("niveau"));
				c.setId_eleve(resultat.getInt("id_eleve"));
				diplome.add(c);
			}
			return diplome;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}
	}

	public void deleteById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("DELETE FROM diplome WHERE id=?");
			ps.setInt(1, id);

			ps.executeUpdate();

			System.out.println("DELETED by Id, OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED by Id, NO");
		}
	}

	public Diplome getByEleve(int id_eleve) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM diplome WHERE id_eleve=?");
			ps.setInt(1, id_eleve);

			ResultSet resultat = ps.executeQuery();

			Diplome c = new Diplome();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setNom(resultat.getString("nom"));
				c.setDate(resultat.getDate("date"));
				c.setNiveau(resultat.getString("niveau"));
				c.setId_eleve(resultat.getInt("id_eleve"));

			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
}