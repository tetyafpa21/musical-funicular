package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import entites.User;

public class UserDao extends Dao {
	
	public UserDao() {
		
	}
	
	public void save(User user) {

		try {

			Connection connexion = this.getConnection();
			if (user.getId() != 0) {
				PreparedStatement ps = connexion.prepareStatement(
						"UPDATE user set login=?, password=?,name=? WHERE id=?");
				ps.setString(1, user.getLogin());
				ps.setString(2, user.getPassword());
				ps.setString(3, user.getName());
				ps.setInt(4, user.getId());
				ps.executeUpdate();
			} else {
				PreparedStatement ps = connexion.prepareStatement(
						"INSERT INTO user (login, password, name) VALUES(?,?,?)");
				ps.setString(1, user.getLogin());
				ps.setString(2, user.getPassword());
				ps.setString(3, user.getName());
				ps.executeUpdate();
			}
			System.out.println("SAVED OK");
			connexion.close();

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public User getById(int id) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM user WHERE id=?");
			ps.setInt(1, id);

			ResultSet resultat = ps.executeQuery();

			User c = new User();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setLogin(resultat.getString("login"));
				c.setPassword(resultat.getString("password"));
				c.setName(resultat.getString("name"));
			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public User getByNameAndPassword(String login, String password) {
		try {
			Connection connexion = this.getConnection();

			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM user WHERE login=? and password=?");
			ps.setString(1, login);
			ps.setString(2, password);

			ResultSet resultat = ps.executeQuery();

			User c = new User();
			if (resultat.next()) {
				c.setId(resultat.getInt("id"));
				c.setLogin(resultat.getString("login"));
				c.setPassword(resultat.getString("password"));
				c.setName(resultat.getString("name"));
			}
			return c;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<User> getAll() {
		ArrayList<User> user = new ArrayList<User>();
		try {
			Connection connexion = this.getConnection();
	
			PreparedStatement ps = connexion.prepareStatement("SELECT * FROM user");
	
			ResultSet resultat = ps.executeQuery();
	
			while (resultat.next()) {
				User c = new User();
				c.setId(resultat.getInt("id"));
				c.setLogin(resultat.getString("login"));
				c.setPassword(resultat.getString("password"));
				c.setName(resultat.getString("name"));
	
				user.add(c);
			}
			return user;
	
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
	
		}
	}

}
