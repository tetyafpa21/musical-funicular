package vues;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import dao.CentreDao;
import dao.DiplomeDao;
import dao.EleveDao;
import dao.FormationDao;
import dao.MatiereDao;
import dao.NoteDao;
import dao.ProfesseurDao;
import dao.ProgrameMatiereDao;
import dao.ProgrammeDao;
import dao.UserDao;
import entites.Centre;
import entites.Diplome;
import entites.Eleve;
import entites.Formation;
import entites.Matiere;
import entites.Note;
import entites.Professeur;
import entites.Programme;
import entites.ProgrammeMatiere;
import entites.User;

public class Application {
	private Scanner clavier = new Scanner(System.in);
	// false car on debug pas
	private boolean estDebug = false;
	// forme de data
	String pattern = "yyyy-MM-dd";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	// utilisateur connecté
	User currentUser;

	public static void main(String[] args) {

		Application app = new Application();
		
		app.initBase();

		User user = app.authentifier();

		// null = vide
		if (user.getName()!=null) {
			// On supprime le password pour ne pas l'afficher
			user.setPassword(null);
			// on met user dans currentUser car currentUser est accessible depuis
			// toutes les fonctions
			app.currentUser = user;
			app.menuPrincipal();
		} else {
			// connexion à échoué on s'arrête
			System.out.println("Erreur de connexion, veuillez recommencer");
			return;
		}
	}

	private User authentifier() {

		UserDao userdao = new UserDao();
		
		System.out.println("Connexion à l'application");
		System.out.print("login: ");
		String login = clavier.nextLine();
		System.out.print("password: ");
		String password = clavier.nextLine();

		User user = userdao.getByNameAndPassword(login, password);

		return user;
	}
	
	//
	private void initBase() {

		UserDao userdao = new UserDao();

		if (userdao.getAll().isEmpty()) {
			User u1, u2;
			u1 = new User("tati", "mypassword", "Tati");
			userdao.save(u1);
			u2 = new User("guest", "password", "Inconnu");
			userdao.save(u2);
		}

		CentreDao centredao = new CentreDao();

		if (centredao.getAll().isEmpty()) {
			Centre c1, c2, c3;
			c1 = new Centre("AFPA", "paris");
			centredao.save(c1);
			c2 = new Centre("FSAD", "lion");
			centredao.save(c2);
			c3 = new Centre("AFPSA", "paris");
			centredao.save(c3);
		}

		FormationDao formationdao = new FormationDao();

		if (formationdao.getAll().isEmpty()) {
			Formation f1 = null, f2 = null, f3;
			f1 = new Formation("Informatique: FrontEnd", centredao.getByName("AFPA").getId(), 10);
			formationdao.save(f1);
			f2 = new Formation("Informatique: SEO", centredao.getByName("FSAD").getId(), 5);
			formationdao.save(f2);
			f3 = new Formation("Informatique: BackEnd", centredao.getByName("AFPSA").getId(), 4);
			formationdao.save(f3);
		}

		ProgrammeDao programmedao = new ProgrammeDao();
//si la table est vide teste
		if (programmedao.getAll().isEmpty()) {
			Programme p1 = null, p2 = null, p3 = null, p4 = null;
			try {
				p1 = new Programme(simpleDateFormat.parse("2021-04-01"), simpleDateFormat.parse("2021-12-01"),
						"FrontEnd - Session 2021", formationdao.getByName("Informatique: FrontEnd").getId());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			programmedao.save(p1);
			try {
				p2 = new Programme(simpleDateFormat.parse("2022-04-01"), simpleDateFormat.parse("2022-12-01"),
						"FrontEnd - Session 2022", formationdao.getByName("Informatique: FrontEnd").getId());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			programmedao.save(p2);
			try {
				p3 = new Programme(simpleDateFormat.parse("2021-08-01"), simpleDateFormat.parse("2021-12-01"),
						"SEO - Session 2021", formationdao.getByName("Informatique: SEO").getId());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			programmedao.save(p3);
			try {
				p4 = new Programme(simpleDateFormat.parse("2019-04-01"), simpleDateFormat.parse("2019-12-01"),
						"FrontEnd - Session 2019", formationdao.getByName("Informatique: FrontEnd").getId());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			programmedao.save(p4);
		}

		MatiereDao matieredao = new MatiereDao();

		if (matieredao.getAll().isEmpty()) {
			Matiere m1 = null, m2 = null, m3 = null;
			m1 = new Matiere("Initiation � HTML");
			matieredao.save(m1);
			m2 = new Matiere("Initiation � CSS");
			matieredao.save(m2);
			m3 = new Matiere("Initiation au SEO");
			matieredao.save(m3);
		}

		ProgrameMatiereDao programmematieredao = new ProgrameMatiereDao();

		if (programmematieredao.getAll().isEmpty()) {
			Programme p1 = programmedao.getByName("FrontEnd - Session 2021");
			Programme p2 = programmedao.getByName("FrontEnd - Session 2022");
			Programme p3 = programmedao.getByName("FrontEnd - Session 2019");

			Matiere m1 = matieredao.getByName("Initiation � HTML");
			Matiere m2 = matieredao.getByName("Initiation � CSS");
			Matiere m3 = matieredao.getByName("Initiation au SEO");
			ProgrammeMatiere pm1 = new ProgrammeMatiere(p1.getId(), m1.getId());
			programmematieredao.save(pm1);
			ProgrammeMatiere pm2 = new ProgrammeMatiere(p2.getId(), m2.getId());
			programmematieredao.save(pm2);
			ProgrammeMatiere pm3 = new ProgrammeMatiere(p3.getId(), m3.getId());
			programmematieredao.save(pm3);
		}

		EleveDao elevedao = new EleveDao();

		if (elevedao.getAll().isEmpty()) {
			Programme p1 = programmedao.getByName("FrontEnd - Session 2021");
			Programme p2 = programmedao.getByName("FrontEnd - Session 2019");
			Eleve e1 = new Eleve("Dupont", "Morisse", "Paris", p1.getId());
			elevedao.save(e1);
			Eleve e2 = new Eleve("Chouteau", "Tati", "Paris", p1.getId());
			elevedao.save(e2);
			Eleve e3 = new Eleve("Dupond", "Morisse", "Argenteuil", p1.getId());
			elevedao.save(e3);
			Eleve e4 = new Eleve("Goerge", "Morisse", "Argenteuil", p2.getId());
			elevedao.save(e4);
			Eleve e5 = new Eleve("Frondu", "Morisse", "Argenteuil", p2.getId());
			elevedao.save(e5);
			Eleve e6 = new Eleve("Profus", "Morisse", "Argenteuil", p2.getId());
			elevedao.save(e6);
		}

		DiplomeDao diplomedao = new DiplomeDao();

		if (diplomedao.getAll().isEmpty()) {
			Eleve e4 = elevedao.getByName("Goerge");
			Eleve e5 = elevedao.getByName("Frondu");
			Eleve e6 = elevedao.getByName("Profus");
			Diplome d1, d2, d3;
			try {
				d1 = new Diplome("Maitrise", simpleDateFormat.parse("2020-01-01"), "bac+4", e4.getId());
				diplomedao.save(d1);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// try catch cest � cause de simpledateformat
			try {
				d2 = new Diplome("Master", simpleDateFormat.parse("2020-01-01"), "bac+5", e5.getId());
				diplomedao.save(d2);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				d3 = new Diplome("BTS", simpleDateFormat.parse("2020-01-01"), "bac+2", e6.getId());
				diplomedao.save(d3);
			} catch (ParseException e) {

				e.printStackTrace();
			}

		}

		ProfesseurDao professeurdao = new ProfesseurDao();

		if (professeurdao.getAll().isEmpty()) {
			Matiere m1 = matieredao.getByName("Initiation � HTML");
			Matiere m2 = matieredao.getByName("Initiation � CSS");
			Matiere m3 = matieredao.getByName("Initiation au SEO");

			Professeur pr1 = new Professeur("Pashan", "Nina", m1.getId());
			professeurdao.save(pr1);
			Professeur pr2 = new Professeur("Richard", "Lea", m2.getId());
			professeurdao.save(pr2);
			Professeur pr3 = new Professeur("Tessier", "Martin", m3.getId());
			professeurdao.save(pr3);
		}

		NoteDao notedao = new NoteDao();

		if (notedao.getAll().isEmpty()) {
			Matiere mt1 = matieredao.getByName("Initiation � HTML");
			Eleve e1 = elevedao.getByName("Chouteau");

			Note nt1 = new Note(13, mt1.getId(), e1.getId());
			notedao.save(nt1);
			Note nt2 = new Note(14, mt1.getId(), e1.getId());
			notedao.save(nt2);
			Note nt3 = new Note(19, mt1.getId(), e1.getId());
			notedao.save(nt3);
		}
	}

	private void menuPrincipal() {
		debug("menuPrincipal()");
		// ascii palm tree
		System.out.println("Bienvenue " + currentUser.toString() + ": Gestion de formations");

		System.out.println(
				"     _______\r\n" + "   /      /,\r\n" + "  /      //\r\n" + " /______//\r\n" + "(______(/\r\n");

		System.out.println();
		while (afficherMenuPrincipal()) {

		}

		clavier.close();
	}

	private boolean afficherMenuPrincipal() {
		debug("afficherMenuPrincipal()");
		System.out.println("MENU PRINCIPAL");

		if (!currentUser.getLogin().equals("guest")) {
			System.out.println("1- Gestion des centres");
			System.out.println("2- Gestion des formations et des programmes");
			System.out.println("3- Gestion des �l�ves");
			System.out.println("4- Gestion des matieres");
		}
		System.out.println("5- Quitter");

		String choix = "";

		ArrayList<String> choixPossible = new ArrayList<>();

		if (!currentUser.getLogin().equals("guest")) {

			choixPossible.add("1");

			choixPossible.add("2");

			choixPossible.add("3");

			choixPossible.add("4");
		}

		choixPossible.add("5");

		choixPossible.add("6");

		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-5) :  ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		switch (choix) {

		case "1":

			menuCentre();

			break;

		case "2":

			menuFormation();

			break;

		case "3":

			menuEleve();

			break;

		case "4":
			menuMatiere();

			break;
		case "5":

			if (quitter())

				return false;

			break;

		case "6":

			estDebug = !estDebug;

			break;
		}

		return true;

	}

	// 1 centre
	private void menuCentre() {
		debug("menuCentre()");
		System.out.println("MENU GESTION DES CENTRES");

		System.out.println("1- Afficher les centres");
		System.out.println("2- Rechercher par un nom du centre");
		System.out.println("3- Creer un centre");
		System.out.println("4- Retour au menu principal");

		String choix = "";

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");

		choixPossible.add("2");

		choixPossible.add("3");
		choixPossible.add("4");

		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-4) : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		switch (choix) {

		case "1":

			afficherTousCentres();

			break;

		case "2":

			rechercheCentreNom();

			break;

		case "3":

			creerOuUpdateCentre(null);

			break;

		}
	}

	private void afficherTousCentres() {
		debug("afficherTousCentres()");
		System.out.println("MENU CENTRES");
		CentreDao centreDao = new CentreDao();
		ArrayList<Centre> listeCentre = centreDao.getAll();
		ArrayList<String> choixPossible = new ArrayList<>();
		int num = 1;
		for (Centre centre : listeCentre) {
			choixPossible.add("" + num);
			System.out.println(num + "- " + centre.toString());
			num++;
		}
		choixPossible.add("" + num);
		System.out.println(num + "- Retour au menu principal");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-" + num + ") : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		if (choix.equals("" + num)) {
			return;
		}

		int choixInt = Integer.parseInt(choix) - 1;

		afficherCentre(listeCentre.get(choixInt));
	}

	private void afficherCentre(Centre centre) {
		debug("afficherCentre()");
		System.out.println(centre.toString());
		System.out.println("1- Modifier un centre");
		System.out.println("2- Supprimer un centre");
		System.out.println("3- Retour au menu principal");

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");
		choixPossible.add("2");
		choixPossible.add("3");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-3) : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		CentreDao centredao = new CentreDao();

		switch (choix) {

		case "1":

			creerOuUpdateCentre(centre);
			break;

		case "2":

			centredao.deleteById(centre.getId());
			break;

		case "3":

			break;

		}
	}

	private void rechercheCentreNom() {
		debug("rechercheCentreNom()");
		System.out.println("MENU DE RECHERCHE DU CENTRE ");
		System.out.println("Quel nom du centre cherchez-vous ?");
		// getting user choice
		String motcle = clavier.nextLine();

		CentreDao centredao = new CentreDao();

		Centre centre = centredao.getByName(motcle);
		afficherCentre(centre);
	}

	private void creerOuUpdateCentre(Centre centre) {
		debug("creerOuUpdateCentre");
		if (centre != null) {
			System.out.println("MENU MISE A JOUR DU CENTRE");
			System.out.print("Nom (" + centre.getNom() + ")?");
		} else {
			System.out.println("MENU DE CREATION DU NOUVEAU CENTRE");
			System.out.print("Quel est le nom du centre?  ");
		}
		String nom = clavier.nextLine();
		if (nom.isEmpty() && centre != null)
			nom = centre.getNom();
		System.out.println();
		if (centre != null) {
			System.out.print("Adresse (" + centre.getAdresse() + ")?");
		} else {
			System.out.print("Quelle est l'adresse du centre?");
		}
		String adresse = clavier.nextLine();
		if (adresse.isEmpty() && centre != null)
			adresse = centre.getAdresse();

		if (centre != null) {
			centre.setNom(nom);
			centre.setAdresse(adresse);
		} else {
			centre = new Centre(nom, adresse);
		}

		CentreDao centredao = new CentreDao();
		centredao.save(centre);
		centre = centredao.getByName(nom);

		System.out.println("Nouveau centre:  " + centre.toString());
	};

	// 2 formation
	private void menuFormation() {
		debug("menuFormation()");
		System.out.println("MENU FORMATION");

		System.out.println("1- Afficher les formations");
		System.out.println("2- Rechercher par nom de formation");
		System.out.println("3- Creer une formation");
		System.out.println("4- Retour au menu principal");

		String choix = "";

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");

		choixPossible.add("2");

		choixPossible.add("3");
		choixPossible.add("4");

		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-4) : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		switch (choix) {

		case "1":

			afficherTousFormations();

			break;

		case "2":

			rechercheFormationNom();

			break;

		case "3":

			creerOuUpdateFormation(null);
			break;

		case "4":

			break;

		}
	}

	private void afficherTousFormations() {
		debug("afficherTousFormations()");
		System.out.println("MENU FORMATIONS");
		FormationDao formationDao = new FormationDao();
		ArrayList<Formation> listeFormation = formationDao.getAll();
		ArrayList<String> choixPossible = new ArrayList<>();
		int num = 1;
		for (Formation formation : listeFormation) {
			choixPossible.add("" + num);
			System.out.println(num + "- " + formation.toString());
			num++;
		}
		choixPossible.add("" + num);
		System.out.println(num + "- Retour au menu principal");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-" + num + ") : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		if (choix.equals("" + num)) {
			return;
		}

		int choixInt = Integer.parseInt(choix) - 1;

		afficherFormation(listeFormation.get(choixInt));
	}

	private void afficherFormation(Formation formation) {
		debug("afficherFormation()");
		System.out.println("MENU D'AFFICHAGE DE LA FORMATION ");
		System.out.println(formation.toString());
		System.out.println("1- Modifier une formation");
		System.out.println("2- Supprimer une formation");
		System.out.println("3- Afficher tous les programmes de la formation");
		System.out.println("4- Ajouter une programmes � la formation");
		System.out.println("5- Retour au menu principal");

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");
		choixPossible.add("2");
		choixPossible.add("3");
		choixPossible.add("4");
		choixPossible.add("5");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-5) : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		FormationDao formationdao = new FormationDao();

		switch (choix) {

		case "1":

			creerOuUpdateFormation(formation);
			break;

		case "2":

			formationdao.deleteById(formation.getId());
			break;

		case "3":
			afficherTousProgrammesByFormation(formation.getId());
			break;

		case "4":
			creerOuUpdateProgramme(null, formation.getId());
			break;

		case "5":
			break;

		}
	}

	private void rechercheFormationNom() {
		debug("rechercheFormationNom()");
		System.out.println("MENU DE RECHERCHE DE LA FORMATION ");
		System.out.println("Quel est le nom de formation ?");
		// getting user choice
		String motcle = clavier.nextLine();

		FormationDao formationdao = new FormationDao();

		Formation formation = formationdao.getByName(motcle);
		afficherFormation(formation);
	}

	private void creerOuUpdateFormation(Formation formation) {
		debug("creerOuUpdateFormation()");
//pour mise � jour sinon cest null
		if (formation != null) {
			System.out.println("MENU MISE A JOUR FORMATION");
			System.out.print("Nom (" + formation.getNom() + ")?");
		} else {
			System.out.println("MENU CREATION FORMATION");
			System.out.print("Donnez le nom de la nouvelle formation: ");

		}
		String nom = clavier.nextLine();
		if (nom.isEmpty() && formation != null)
			nom = formation.getNom();
		System.out.println();
		if (formation != null) {
			System.out.print("Prix (" + formation.getPrix() + ")?");
		} else {
			System.out.print("Donnez le prix de la nouvelle formation (xxx,x):  ");
		}

		String prixString = clavier.nextLine();

		float prix;
		if (formation != null && prixString.isEmpty())
			prix = formation.getPrix();
		else {
			try {
				prix = Float.parseFloat(prixString);
			} catch (NumberFormatException e) {
				System.out.println("Erreur de saisie du prix (xxx,x)");
				return;
			}
		}

		CentreDao centredao = new CentreDao();
		if (formation != null) {
			System.out.print("Donnez le nom du centre (" + centredao.getById(formation.getId_centre()) + ")?");
		} else {
			System.out.print("Donnez le nom du centre:  ");
		}

		String nomCentre = clavier.nextLine();
		int id_centre;
		if (formation != null && nomCentre.isEmpty()) {
			id_centre = formation.getId_centre();
		} else {
			Centre centre = centredao.getByName(nomCentre);
			if (centre.getNom() == null) {
				System.out.println("Centre non trouv� - recommencer la saisie.");
				return;
			} else {
				id_centre = centre.getId();
			}
		}

		if (formation != null) {
			formation.setNom(nom);
			formation.setPrix(prix);
			formation.setId_centre(id_centre);
		} else {
			formation = new Formation(nom, id_centre, prix);
		}
//sauvregarde, puis recherche � nouveau dans la base cars formation � id que on ne voit pas
		FormationDao formationdao = new FormationDao();
		formationdao.save(formation);
		// recherche par nom :)
		formation = formationdao.getByName(nom);
//affiche tout les champs y compris id
		System.out.println("Formation cr�e: " + formation.toString());
	};

	// 3 eleve
	private void menuEleve() {
		debug("menuEleve()");
		System.out.println("MENU ELEVE");

		System.out.println("1- Afficher les eleves");
		System.out.println("2- Chercher par le nom d'eleve");
		System.out.println("3- Inscrire un eleve");
		System.out.println("4- Retour au menu principal");

		String choix = "";

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");

		choixPossible.add("2");

		choixPossible.add("3");
		choixPossible.add("4");

		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie");

			System.out.print("Votre choix (1-4) : ");
			choix = clavier.nextLine();

			premierSaisie = false;

		}

		switch (choix) {

		case "1":

			afficherTousEleves();

			break;

		case "2":

			rechercheEleveNom();

			break;

		case "3":

			creerOuUpdateEleve(null);

			break;
		case "4":

			break;

		}
	}

	private void afficherTousEleves() {
		debug("afficherTousEleves()");
		System.out.println("MENU ELEVES");
		EleveDao eleveDao = new EleveDao();
		ArrayList<Eleve> listeEleve = eleveDao.getAll();
		ArrayList<String> choixPossible = new ArrayList<>();
		int num = 1;
		for (Eleve eleve : listeEleve) {
			choixPossible.add("" + num);
			System.out.println(num + "- " + eleve.toString());
			num++;
		}
		choixPossible.add("" + num);
		System.out.println(num + "- Retour au menu principal");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie");

			System.out.print("Votre choix (1-" + num + ") : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		if (choix.equals("" + num)) {
			return;
		}

		int choixInt = Integer.parseInt(choix) - 1;

		afficherEleve(listeEleve.get(choixInt));
	}

	private void afficherEleve(Eleve eleve) {
		debug("afficherEleve()");
		System.out.println("MENU D'AFFICHAGE D'ELEVE ");
		System.out.println(eleve.toString());

		DiplomeDao diplomedao = new DiplomeDao();
		Diplome diplome = diplomedao.getByEleve(eleve.getId());
		if (diplome.getNom() != null) {
			System.out.println("Eleve diplom� : " + diplome.toString());
		}

		System.out.println("1- Modifier l'eleve");
		System.out.println("2- Supprimer l'eleve");
		System.out.println("3- G�r� les notes de l'eleve");
		System.out.println("4- Retour au menu principal");

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");
		choixPossible.add("2");
		choixPossible.add("3");
		choixPossible.add("4");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-4) : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		EleveDao elevedao = new EleveDao();

		switch (choix) {

		case "1":

			creerOuUpdateEleve(eleve);
			break;

		case "2":

			elevedao.deleteById(eleve.getId());
			break;

		case "3":
			afficheMenuNoteEleve(eleve);
			break;

		case "4":
			break;

		}
	}

	private void creerOuUpdateEleve(Eleve eleve) {
		debug("creerOuUpdateEleve()");
		if (eleve != null) {
			System.out.println("MENU MISE A JOUR D'UN ELEVE");
			System.out.print("Nom d'�leve: " + eleve.getNom() + " ?");
		} else {
			System.out.println("MENU CREATION ELEVE");
			System.out.print("Quel est son nom?");
		}
		String nom = clavier.nextLine();
		if (nom.isEmpty() && eleve != null)
			nom = eleve.getNom();

		System.out.println();
		if (eleve != null) {
			System.out.print("Pr�nom: " + eleve.getPrenom() + " ?");
		} else {
			System.out.print("Quel est son pr�nom?");
		}
		String prenom = clavier.nextLine();
		if (prenom.isEmpty() && eleve != null)
			prenom = eleve.getPrenom();

		System.out.println();
		if (eleve != null) {
			System.out.print("Ville: " + eleve.getVille() + " ?");
		} else {
			System.out.print("Quel est sa ville?  ");
		}
		String ville = clavier.nextLine();
		if (ville.isEmpty() && eleve != null)
			ville = eleve.getVille();

		if (eleve != null) {
			eleve.setNom(nom);
			eleve.setPrenom(prenom);
			eleve.setVille(ville);
		} else {

			System.out.print("Donnez le nom de la formation? ");
			String nomFormation = clavier.nextLine();
			FormationDao formationdao = new FormationDao();
			Formation formation = formationdao.getByName(nomFormation);
			if (formation.getNom() == null) {
				System.out.println("Formation n'existe pas - veuillez recommencer");
				return;
			}

			ProgrammeDao programmedao = new ProgrammeDao();
			ArrayList<Programme> listeProgramme = programmedao.getAllByFormation(formation.getId());

			if (listeProgramme.isEmpty()) {
				System.out.println("Il n'existe pas de programme dans cette formation - veuillez recommencer");
				return;
			}

			System.out.println("Choix du programme : ");
			ArrayList<String> choixPossible = new ArrayList<>();
			int num = 1;
			for (Programme prog : listeProgramme) {
				System.out.println(num + "- " + prog.toString());
				choixPossible.add("" + num);
				num++;
			}

			System.out.println(num + "- Annuler");

			String choix = "";
			boolean premierSaisie = true;

			while (!choixPossible.contains(choix)) {

				if (!premierSaisie)

					System.out.println("Erreur de saisie.");

				System.out.print("Votre choix (1-" + num + ") : ");

				choix = clavier.nextLine();

				premierSaisie = false;

			}

			if (choix.equals("" + num)) {
				return;
			}

			Programme programmeChoisi = listeProgramme.get(Integer.parseInt(choix) - 1);

			eleve = new Eleve(nom, prenom, ville, programmeChoisi.getId());
		}

		EleveDao elevedao = new EleveDao();
		elevedao.save(eleve);
		eleve = elevedao.getByName(nom);

		System.out.println("Nouveau �l�ve: " + eleve.toString());
	};

	private void rechercheEleveNom() {
		debug("rechercheEleveNom()");
		System.out.println("MENU DE RECHERCHE D'ELEVE ");
		System.out.println("Quel nom souhaitez-vous rechercher ?");
		// getting user choice
		String motcle = clavier.nextLine();

		EleveDao elevedao = new EleveDao();

		Eleve eleve = elevedao.getByName(motcle);
		afficherEleve(eleve);
	}

	// 4 Matiere
	private void menuMatiere() {
		debug("menuMatiere()");
		System.out.println("MENU MATIERE");

		System.out.println("1- Afficher les mati�res");
		System.out.println("2- Rechercher par le nom de mati�re");
		System.out.println("3- Nouvelle mati�re");
		System.out.println("4- Retour au menu principal");

		String choix = "";

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");

		choixPossible.add("2");

		choixPossible.add("3");
		choixPossible.add("4");

		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-4) : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		switch (choix) {

		case "1":

			afficherTousMatieres();

			break;

		case "2":

			rechercheMatiereNom();

			break;

		case "3":

			creerOuUpdateMatiere(null);

		case "4":

			break;

		}
	}

	private void afficherTousMatieres() {
		debug("afficherTousMatieres()");
		System.out.println("MENU D'AFFICHAGE DES MATIERES");
		System.out.println();
		MatiereDao matiereDao = new MatiereDao();
		ArrayList<Matiere> listeMatiere = matiereDao.getAll();
		ArrayList<String> choixPossible = new ArrayList<>();
		int num = 1;
		for (Matiere matiere : listeMatiere) {
			choixPossible.add("" + num);
			System.out.println(num + "- " + matiere.toString());
			num++;
		}
		choixPossible.add("" + num);
		System.out.println(num + "- Retour au menu principal");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-" + num + ") : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		if (choix.equals("" + num)) {
			return;
		}

		int choixInt = Integer.parseInt(choix) - 1;

		afficherMatiere(listeMatiere.get(choixInt));
	}

	private void afficherMatiere(Matiere matiere) {
		debug("afficherMatiere()");
		System.out.println("MENU D'AFFICHAGE DES MATIERE");
		System.out.println(matiere.toString());

		ProfesseurDao professeurdao = new ProfesseurDao();
		Professeur prof = professeurdao.getByMatiere(matiere.getId());
		System.out.println("Professeur : " + prof.toString());

		System.out.println("1- Modifier un mati�re");
		System.out.println("2- Supprimer un mati�re");
		System.out.println("3- Retour au menu principal");

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");
		choixPossible.add("2");
		choixPossible.add("3");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-3) : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		MatiereDao matieredao = new MatiereDao();

		switch (choix) {

		case "1":

			creerOuUpdateMatiere(matiere);
			break;

		case "2":

			((MatiereDao) matieredao).deleteById(matiere.getId());
			break;

		case "3":

			break;

		}
	}

	private void rechercheMatiereNom() {
		debug("rechercheMatiereNom()");
		System.out.println("MENU DE RECHERCHE DE LA MATIERE ");
		System.out.println("Quel nom d'un mati�re cherchez-vous ?");

		String motcle = clavier.nextLine();

		MatiereDao matieredao = new MatiereDao();

		Matiere matiere = matieredao.getByName(motcle);
		afficherMatiere(matiere);
	}

	private void creerOuUpdateMatiere(Matiere matiere) {
		debug("creerOuUpdateMatiere()");
		if (matiere != null) {
			System.out.println("MENU MISE A JOUR UN MATIERE");
			System.out.print("Nom:  " + matiere.getNom() + "  ?");
		} else {
			System.out.println("MENU NOUVEAU MATIERE");
			System.out.print("Quel est nom du nouveau matiere?  ");

		}
		String nom = clavier.nextLine();
		if (nom.isEmpty() && matiere != null)
			nom = matiere.getNom();
		System.out.println();
		if (matiere != null) {
			System.out.print("Nom: " + matiere.getNom() + "  ?");
		}

		if (matiere != null) {
			matiere.setNom(nom);
		} else {
			matiere = new Matiere(nom);
		}

		MatiereDao matieredao = new MatiereDao();
		matieredao.save(matiere);
		matiere = matieredao.getByName(nom);

		System.out.println("Nouveau matiere:  " + matiere.toString());
	};

	private void afficherTousProgrammesByFormation(int id_formation) {
		debug("afficherTousProgrammesByFormation(int id_formation)");
		System.out.println("MENU FORMATIONS - PROGRAMMES");
		ProgrammeDao programmeDao = new ProgrammeDao();
		ArrayList<Programme> listeProgramme = programmeDao.getAllByFormation(id_formation);
		ArrayList<String> choixPossible = new ArrayList<>();
		int num = 1;
		for (Programme programme : listeProgramme) {
			choixPossible.add("" + num);
			System.out.println(num + "- " + programme.toString());
			num++;
		}
		choixPossible.add("" + num);
		System.out.println(num + "- Retour au menu principal");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-" + num + ") : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		if (choix.equals("" + num)) {
			return;
		}

		int choixInt = Integer.parseInt(choix) - 1;

		afficherProgramme(listeProgramme.get(choixInt));
	}

	private void afficherProgramme(Programme programme) {
		debug("afficherProgramme()");
		System.out.println("MENU D'AFFICHAGE DU PROGRAMME ");
		System.out.println(programme.toString());

		FormationDao formationdao = new FormationDao();
		Formation formation = formationdao.getById(programme.getId_formation());
		float prix = formation.getPrix();

		EleveDao elevedao = new EleveDao();
		int nbEleveProgramme = elevedao.getByIdProgramme(programme.getId()).size();

		float prixProgramme = prix * nbEleveProgramme;

		System.out.println("Montant total du programme : " + prixProgramme);

		System.out.println("1- Modifier un programme");
		System.out.println("2- Supprimer un programme");
		System.out.println("3- Retour au menu principal");

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");
		choixPossible.add("2");
		choixPossible.add("3");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-5) : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		ProgrammeDao programmedao = new ProgrammeDao();

		switch (choix) {

		case "1":

			creerOuUpdateProgramme(programme, programme.getId_formation());
			break;

		case "2":

			programmedao.deleteById(programme.getId());
			break;

		case "3":

			break;

		case "5":

			break;

		}
	}

	private void creerOuUpdateProgramme(Programme programme, int id_formation) {
		debug("creerOuUpdateProgramme(Programme programme, int id_formation)");
		if (programme != null) {
			System.out.println("MENU MISE A JOUR PROGRAMME");
			System.out.print("Nom (" + programme.getNom() + ")?");
		} else {
			System.out.println("MENU CREATION PROGRAMME");
			System.out.print("Donnez le nom du nouveau programme: ");

		}
		String nom = clavier.nextLine();
		if (nom.isEmpty() && programme != null)
			nom = programme.getNom();
		System.out.println();

		if (programme != null) {
			System.out.print("Date de d�but (" + programme.getDate_debut() + ")?");
		} else {
			System.out.print("Date de d�but (aaaa-mm-jj):  ");
		}

		String dateString = clavier.nextLine();

		Date date_Debut;
		if (programme != null && dateString.isEmpty())
			date_Debut = programme.getDate_debut();
		else {
			try {
				date_Debut = simpleDateFormat.parse(dateString);
			} catch (ParseException e) {
				System.out.println("Erreur de format de date - veuillez recommencer");
				return;
			}
		}

		if (programme != null) {
			System.out.print("Date de fin (" + programme.getDate_fin() + ")?");
		} else {
			System.out.print("Date de fin (aaaa-mm-jj):  ");
		}

		dateString = clavier.nextLine();

		Date date_Fin;
		if (programme != null && dateString.isEmpty())
			date_Fin = programme.getDate_fin();
		else {
			try {
				date_Fin = simpleDateFormat.parse(dateString);
			} catch (ParseException e) {
				System.out.println("Erreur de format de date - veuillez recommencer");
				return;
			}
		}

		if (programme != null) {
			programme.setNom(nom);
			programme.setDate_debut(date_Debut);
			programme.setDate_fin(date_Fin);
			programme.setId_formation(id_formation);
		} else {
			programme = new Programme(date_Debut, date_Fin, nom, id_formation);
		}

		ProgrammeDao programmedao = new ProgrammeDao();
		programmedao.save(programme);
		programme = programmedao.getByName(nom);

		System.out.println("Programme : " + programme.toString());
	};

	private void afficheMenuNoteEleve(Eleve eleve) {
		debug("afficheMenuNoteEleve()");
		System.out.println("GERER NOTES DE " + eleve.getNom() + " " + eleve.getPrenom());
		NoteDao notedao = new NoteDao();
		MatiereDao matieredao = new MatiereDao();
		FormationDao formationdao = new FormationDao();
		ProgrammeDao programmeDao = new ProgrammeDao();
		EleveDao elevedao = new EleveDao();

		Programme programme = programmeDao.getById(eleve.getId_programme());
		Formation formation = formationdao.getById(programme.getId_formation());
		System.out.println("Formation : " + formation.getNom() + " - " + programme.getNom() + " - du "
				+ programme.getDate_debut() + " au " + programme.getDate_fin());

		// moyenne generale du programme
		ArrayList<Eleve> listeEleveProgramme = elevedao.getByIdProgramme(programme.getId());
		float sommeprogramme = 0;
		int count = 0;
		for (Eleve eleveProgramme : listeEleveProgramme) {
			ArrayList<Note> listeNote = notedao.getByEleve(eleveProgramme.getId());
			for (Note note : listeNote) {
				sommeprogramme += note.getNote();
				count++;
			}
		}
		float moyenneProgramme = sommeprogramme / count;

		// moyenne de l'�l�ve
		ArrayList<Note> listeNote = notedao.getByEleve(eleve.getId());
		if (!listeNote.isEmpty()) {
			float somme = 0;
			for (Note note : listeNote) {
				Matiere matiere = matieredao.getById(note.getId_matiere());
				System.out.println(matiere.getNom() + " : " + note.getNote());
				somme += note.getNote();
			}
			float moyenne = somme / listeNote.size();
			System.out.println("Moyenne g�n�rale : " + moyenne + " (moyenne du programme : " + moyenneProgramme + ")");
		}

		System.out.println("1- Ajouter une note");
		System.out.println("2- Retour menu principale");

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("1");
		choixPossible.add("2");

		String choix = "";
		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (!premierSaisie)

				System.out.println("Erreur de saisie.");

			System.out.print("Votre choix (1-2) : ");

			choix = clavier.nextLine();

			premierSaisie = false;

		}

		if (choix.equals("1")) {
			System.out.println("Matiere ?");
			String matiereChoix = clavier.nextLine();
			Matiere matiere = matieredao.getByName(matiereChoix);
			if (matiere.getNom() == null) {
				System.out.println("Matiere non trouv� - veuillez recommencer");
				return;
			}
			System.out.println("Note ?");
			String noteString = clavier.nextLine();
			try {
				float note = Float.parseFloat(noteString);
				Note noteEleve = new Note(note, matiere.getId(), eleve.getId());
				notedao.save(noteEleve);
				System.out.println("Note ajout�e " + noteEleve.toString());
			} catch (NumberFormatException e) {
				System.out.println("Erreur de saisie");
			}
		}
	}

	private boolean quitter() {

		debug("quitter()");

		String choix = "";

		ArrayList<String> choixPossible = new ArrayList<>();

		choixPossible.add("O");

		choixPossible.add("N");

		boolean premierSaisie = true;

		while (!choixPossible.contains(choix)) {

			if (premierSaisie != true)

				System.out.println("Erreur de saisie.");

			System.out.print("Etez-vous s�r de vouloir quitter (O/N) : ");

			choix = clavier.nextLine();

			choix = choix.toUpperCase();

			premierSaisie = false;

		}

		if (choix.equals("N"))

			return false;

		return true;

	}

	private void debug(String methode) {
		if (estDebug) {
			System.out.println("-------------------------> Entr�e dans la m�thode " + methode);
		}
	}

}
